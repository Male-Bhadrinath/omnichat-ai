# 🎬 OmniChat AI — 2-Minute Loom Video Script
## SummerShip Challenge 2026 · Problem Code #05

---

> ⏱️ Total Duration: ~2 minutes
> 🎤 Record screen + voice. Show the live deployed app throughout.
> Keep energy high, pace fast, voice confident.

---

## [0:00 – 0:15] HOOK + PROBLEM (15 seconds)

**SHOW:** Dashboard page of your app

**SAY:**
> "Imagine you're a business owner. Your WhatsApp has 50 unread messages.
> Instagram has 30 DMs. Facebook has 20. LinkedIn has 10.
> And you missed 5 phone calls — all while you were sleeping.
> That's the reality for millions of small businesses every single day.
> I built OmniChat AI to solve exactly this problem."

---

## [0:15 – 0:30] SOLUTION OVERVIEW (15 seconds)

**SHOW:** Pan slowly across the Dashboard — KPI cards, recent conversations, channel pills

**SAY:**
> "OmniChat AI is a unified conversational AI platform that brings every channel —
> WhatsApp, Instagram, Facebook, LinkedIn, Voice, and Website — into ONE intelligent inbox.
> AI handles replies automatically, 24/7. No human needed for routine queries.
> Look at these numbers: 1,284 messages handled today, 94% auto-reply rate,
> and response time dropped from 12 hours to just 1.4 seconds."

---

## [0:30 – 0:55] FEATURE DEMO — INBOX + AI CHAT (25 seconds)

**SHOW:** Click to Unified Inbox → show conversations → then click AI Chat Simulator

**SAY:**
> "Here's the Unified Inbox — every conversation across all channels, live.
> Now watch the AI agent in action."

*(Type in the chat: "I want to book an appointment")*

> "The AI instantly responds, offers available slots — [pause] — I select 2 PM —
> appointment confirmed. No human involved. This is real-time AI, right here."

*(Now click: "What are your prices?" quick prompt)*

> "Pricing question? The AI knows your business — responds instantly with plans and a CTA."

---

## [1:00 – 1:15] LEAD MANAGER + APPOINTMENTS (15 seconds)

**SHOW:** Click Lead Manager → show pipeline table → click Appointments tab

**SAY:**
> "Every conversation that captures a contact goes straight into the Lead Manager.
> Name, phone, email, channel, pipeline value — all auto-captured.
> And every appointment the AI books shows up here, confirmed, with one click.
> That's automated lead generation and scheduling, zero manual effort."

---

## [1:15 – 1:35] KNOWLEDGE BASE + ANALYTICS (20 seconds)

**SHOW:** Click Knowledge Base → show articles + training status → click Analytics

**SAY:**
> "You train the AI through the Knowledge Base — add FAQs, pricing, policies —
> and the AI learns your business language. Training status? 95% on FAQs, 100% on pricing.
> The Analytics dashboard shows 7-day trends: message volume per channel,
> response time dropping week over week, and lead conversion climbing to 23%.
> This is data-driven automation."

---

## [1:35 – 1:50] TECH STACK (15 seconds)

**SHOW:** Settings page → Channels tab → AI Config tab

**SAY:**
> "Under the hood: Meta Cloud API for WhatsApp, Instagram, and Facebook.
> Twilio for voice calls. LinkedIn API v2 for professional outreach.
> A RAG-powered LLM agent trained on your Knowledge Base.
> WebSockets for real-time unified inbox. Google Sheets CRM sync.
> The full stack the problem statement asked for — all connected."

---

## [1:50 – 2:00] CLOSE (10 seconds)

**SHOW:** Dashboard one more time — wide shot

**SAY:**
> "OmniChat AI turns a scattered, manual communication nightmare into
> a single, automated, AI-powered business engine.
> Never miss a lead. Never delay a reply. Book appointments while you sleep.
> This is OmniChat AI — built for SummerShip 2026. Thank you."

---

## 🎬 Recording Tips

1. **Open the deployed app BEFORE recording** — no loading delays
2. **Use Chrome with Loom extension** — screen + webcam bubble
3. **Practice once without recording** — know where to click
4. **Keep the sidebar visible** — it shows all features at a glance
5. **Speak slightly faster than normal** — 2 minutes goes fast
6. **Set Loom to PUBLIC before copying the link**
7. **Best lighting:** face a window, don't record with light behind you

## ⚡ Quick Click Order for Recording
Dashboard → Unified Inbox → AI Chat Simulator (type + send 2 messages) → Lead Manager → Appointments → Knowledge Base → Analytics → Settings → back to Dashboard
